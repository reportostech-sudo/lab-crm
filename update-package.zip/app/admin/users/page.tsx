import { fetchUsers, fetchGroups } from "@/app/lib/user-actions";
import { auth } from "@/auth";
import { prisma } from "@/app/lib/prisma";
import AddUserModal from "@/components/admin/AddUserModal";
import EditUserModal from "@/components/admin/EditUserModal";
import UnblockUserButton from "@/components/admin/UnblockUserButton"; // New Import
import { ShieldAlert } from "lucide-react";
import { getShifts } from "@/app/lib/shift-actions";

export const metadata = {
    title: "User Management | Sukra Admin",
};

import { checkPermission } from "@/app/lib/auth-check";
import AccessDenied from "@/components/admin/AccessDenied";

export default async function UsersPage() {
    // Permission Check
    const { authorized, user: currentUser } = await checkPermission('users:read');
    if (!authorized) return <AccessDenied />;

    const users = await fetchUsers();
    const groups = await fetchGroups();

    // Redundant manual auth fetch removed since checkPermission returns the user


    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <AddUserModal groups={groups} currentUser={currentUser} />
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                <table className="w-full text-left">
                    <thead className="bg-gray-50 border-b border-gray-200">
                        <tr className="text-gray-500 text-sm uppercase">
                            <th className="px-6 py-4 font-medium">Name</th>
                            <th className="px-6 py-4 font-medium">Email</th>
                            <th className="px-6 py-4 font-medium">Role</th>
                            <th className="px-6 py-4 font-medium">Group</th>
                            <th className="px-6 py-4 font-medium text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                        {users.map((user: any) => (
                            <tr key={user.id} className="hover:bg-gray-50 transition-colors">
                                <td className="px-6 py-4 font-medium text-gray-900">
                                    <div className="flex items-center gap-2">
                                        {user.name || "No Name"}
                                        {user.isBlocked && (
                                            <span className="text-red-500" title="Account Blocked">
                                                <ShieldAlert size={16} />
                                            </span>
                                        )}
                                    </div>
                                </td>
                                <td className="px-6 py-4 text-gray-600">{user.email}</td>
                                <td className="px-6 py-4">
                                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${user.role === 'ADMIN'
                                        ? 'bg-purple-100 text-purple-700'
                                        : 'bg-blue-100 text-blue-700'
                                        }`}>
                                        {user.role}
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-gray-500">
                                    {user.group ? (
                                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                            {user.group.name}
                                        </span>
                                    ) : (
                                        <span className="text-gray-400 italic">No Group</span>
                                    )}
                                </td>
                                <td className="px-6 py-4 text-right flex items-center justify-end gap-2">
                                    <UnblockUserButton userId={user.id} isBlocked={user.isBlocked} currentUser={currentUser} />
                                    <EditUserModal user={user} groups={groups} currentUser={currentUser} />
                                </td>
                            </tr>
                        ))}
                        {users.length === 0 && (
                            <tr>
                                <td colSpan={5} className="text-center py-10 text-gray-500">
                                    No users found. Create one to get started.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
